//
//  SignViewController.swift
//  Pet-prjct
//
//  Created by Pavel on 01.03.2021.
//

import UIKit

class SignViewController: Helpers {
    @IBOutlet weak var nameTF: UITextField!
    @IBOutlet weak var secondNameTF: UITextField!
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    @IBOutlet weak var repeatPasswordTF: UITextField!
    @IBAction func SignButton(_ sender: UIButton) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
